function MovieDetailPage() {
  return (
    <div className="ContactPage">
      <p>MovieDetailPage</p>
    </div>
  );
}

export default MovieDetailPage;