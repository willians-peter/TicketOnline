function HomePage() {
  return (
    <div className="HomePage">
      <p>HomePage</p>
    </div>
  );
}

export default HomePage;