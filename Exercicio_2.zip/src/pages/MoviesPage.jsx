function MoviePage() {
  return (
    <div className="ContactPage">
      <p>MoviePage</p>
    </div>
  );
}

export default MoviePage;