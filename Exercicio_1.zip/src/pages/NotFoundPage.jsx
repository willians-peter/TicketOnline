function NotFoundPage() {
  return (
    <div className="NotFoundPage">
      <p>404 not found page.</p>
    </div>
  );
}

export default NotFoundPage;