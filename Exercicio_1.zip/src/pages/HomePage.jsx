function HomePage() {
  return (
    <div className="ContactPage">
      <p>HomePage</p>
    </div>
  );
}

export default HomePage;