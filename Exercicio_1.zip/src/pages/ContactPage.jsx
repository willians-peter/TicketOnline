function ContactPage() {
  return (
    <div className="ContactPage">
      <p>ContactPage</p>
    </div>
  );
}

export default ContactPage;